import { Injectable } from '@angular/core';

@Injectable()
export class <%= classify(name) %>Service {

  constructor() { }

}
