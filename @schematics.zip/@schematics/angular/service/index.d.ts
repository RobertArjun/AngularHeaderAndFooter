import { Rule } from '@angular-devkit/schematics';
import { Schema as ServiceOptions } from './schema';
export default function (options: ServiceOptions): Rule;
