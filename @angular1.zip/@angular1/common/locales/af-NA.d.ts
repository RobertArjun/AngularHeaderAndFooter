declare const _default: (string | number | string[] | string[][] | number[] | ((n: number) => number))[];
export default _default;
