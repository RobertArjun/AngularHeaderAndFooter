export interface UpdateTaskOptions {
    dryRun: boolean;
    force: boolean;
    next: boolean;
}
export declare const UpdateTask: any;
