export interface SetOptions {
    global?: boolean;
}
declare const SetCommand: any;
export default SetCommand;
