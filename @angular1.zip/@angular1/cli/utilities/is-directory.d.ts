export declare function isDirectory(path: string): boolean;
