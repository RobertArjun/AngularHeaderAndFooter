"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var schema_class_factory_1 = require("./schema-class-factory");
exports.SchemaClassFactory = schema_class_factory_1.SchemaClassFactory;
//# sourceMappingURL=/users/hansl/sources/hansl/angular-cli/src/index.js.map