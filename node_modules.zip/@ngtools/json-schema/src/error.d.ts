export declare class JsonSchemaErrorBase extends Error {
    constructor(message?: string);
}
