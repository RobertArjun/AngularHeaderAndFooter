/**
 * The ng module for forms.
 * @stable
 */
export declare class FormsModule {
}
/**
 * The ng module for reactive forms.
 * @stable
 */
export declare class ReactiveFormsModule {
}
